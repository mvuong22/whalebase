// Enum for the conservation status of whales
public enum ConservationStatus {
    LEAST_CONCERN,
    VULNERABLE,
    ENDANGERED,
    CRITICALLY_ENDANGERED
}

