// Entry point for Whale Base
public class Main {
    public static void main(String[] args) {
        MenuUI ui = new MenuUI();
        ui.start();
    }
}
